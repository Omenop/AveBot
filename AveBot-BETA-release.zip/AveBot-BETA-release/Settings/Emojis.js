export default {
  // you can change this to custom emoji, e.g "<nobody_pause:1045789999444>"
  link: "🔗",
  support: "🔩",
  ticket: "🎫",
  back: "⬅️",
  next: "➡️",
  delete: "🗑",
  home: "🏠",
  cancel: "❌",
}