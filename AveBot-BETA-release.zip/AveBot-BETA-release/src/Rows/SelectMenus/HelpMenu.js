
/**@type {import("#root/Types.js").SelectMenus}**/
export default {
  name: "helpMenu",
  async execute(client, interaction, data){
    const commands = client
  }
}